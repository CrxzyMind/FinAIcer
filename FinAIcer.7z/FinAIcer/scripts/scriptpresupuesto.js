  document.addEventListener('DOMContentLoaded', function() {
            // Elementos del modal
            const modal = document.getElementById('modalAgregarCategoria');
            const btnAgregar = document.getElementById('btnAgregarCategoria');
            const btnCancelar = document.getElementById('btnCancelar');
            const formCategoria = document.getElementById('formCategoria');
            
            // Abrir modal
            btnAgregar.addEventListener('click', function() {
                modal.style.display = 'flex';
            });
            
            // Cerrar modal
            btnCancelar.addEventListener('click', function() {
                modal.style.display = 'none';
            });
            
            // Cerrar modal al hacer clic fuera del contenido
            window.addEventListener('click', function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            });
            
            // Manejar envío del formulario
            formCategoria.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const nombre = document.getElementById('nombreCategoria').value;
                const presupuesto = document.getElementById('presupuestoCategoria').value;
                const color = document.getElementById('colorCategoria').value;
                
                // Crear nueva categoría
                agregarCategoria(nombre, presupuesto, color);
                
                // Cerrar modal y resetear formulario
                modal.style.display = 'none';
                formCategoria.reset();
            });
            
            // Función para agregar nueva categoría
            function agregarCategoria(nombre, presupuesto, color) {
                const categoriasContainer = document.querySelector('.categorias');
                
                // Crear elemento de categoría
                const nuevaCategoria = document.createElement('div');
                nuevaCategoria.className = 'categoria';
                
                // Calcular valores aleatorios para simular gastos
                const gastado = Math.floor(Math.random() * presupuesto * 0.7);
                const porcentaje = (gastado / presupuesto * 100).toFixed(1);
                const restante = presupuesto - gastado;
                
                // Determinar clase de color basado en el seleccionado
                let claseColor = 'comestibles';
                if (color === '#3498db') claseColor = 'transporte';
                else if (color === '#e74c3c') claseColor = 'vivienda';
                else if (color === '#f39c12') claseColor = 'entretenimiento';
                else if (color === '#9b59b6') claseColor = 'salud';
                
                nuevaCategoria.innerHTML = `
                    <div class="categoria-header">
                        <div class="categoria-nombre">${nombre}</div>
                        <div class="categoria-monto">$${gastado} of $${presupuesto}</div>
                    </div>
                    <div class="categoria-progreso">
                        <div class="categoria-progreso-interno" style="background-color: ${color}; width: ${porcentaje}%"></div>
                    </div>
                    <div class="categoria-restante">$${restante} restantes</div>
                `;
                
                // Agregar al contenedor de categorías
                categoriasContainer.appendChild(nuevaCategoria);
                
                // Actualizar resumen general
                actualizarResumenGeneral();
            }
            
            // Función para actualizar el resumen general
            function actualizarResumenGeneral() {
                // En una aplicación real, aquí se recalcularían todos los valores
                // Por simplicidad, solo mostraremos un mensaje de actualización
                console.log('Resumen general actualizado');
            }
            
            // Navegación entre secciones
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    navItems.forEach(nav => nav.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Aquí podrías agregar lógica para cambiar de sección
                    const seccion = this.querySelector('span').textContent;
                    console.log('Navegando a: ' + seccion);
                    
                    // Redirigir a la página correspondiente
                    if (seccion === 'Inicio') {
                        window.location.href = '../index.html'; // Página principal
                    }
                    if (seccion === 'Presupuesto') {
                        window.location.href = ''; // Página principal
                    }
                    if (seccion === 'Chat IA') {
                        window.location.href = 'chat.html'; // Página principal
                    }
                   
                   
                });
            });
        });