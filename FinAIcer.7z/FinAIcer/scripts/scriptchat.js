document.addEventListener('DOMContentLoaded', function() {
            const chatContainer = document.getElementById('chatContainer');
            const inputMensaje = document.getElementById('inputMensaje');
            const btnEnviar = document.getElementById('btnEnviar');
            const mensajeCargando = document.getElementById('mensajeCargando');
            const botonesOpciones = document.querySelectorAll('.btn-opcion');
            
            // Respuestas predefinidas del asistente IA
            const respuestasIA = {
                "¿Cómo puedo ahorrar más dinero este mes?": {
                    titulo: "Basándome en tus patrones de gasto, recomiendo:",
                    puntos: [
                        "Reducir comidas fuera por $200/mes",
                        "Cambiar a un plan de teléfono más barato (ahorro $30)",
                        "Usar la regla de presupuesto 50/30/20"
                    ],
                    adicional: "¿Te gustaría que profundice en alguna de estas recomendaciones?"
                },
                "¿Cómo crear un presupuesto?": {
                    titulo: "Para crear un presupuesto efectivo, sigue estos pasos:",
                    puntos: [
                        "Registra todos tus ingresos mensuales",
                        "Identifica y categoriza tus gastos fijos y variables",
                        "Establece metas de ahorro realistas",
                        "Utiliza la regla 50/30/20 (necesidades/deseos/ahorro)",
                        "Revisa y ajusta tu presupuesto regularmente"
                    ],
                    adicional: "Puedo ayudarte a crear un presupuesto personalizado basado en tus datos."
                },
                "Analiza mis gastos del último mes": {
                    titulo: "Análisis de tus gastos del último mes:",
                    puntos: [
                        "Gastos en alimentación: $580 (25% de tus ingresos)",
                        "Servicios y vivienda: $900 (39% de tus ingresos)",
                        "Transporte: $250 (11% de tus ingresos)",
                        "Entretenimiento: $200 (9% de tus ingresos)",
                        "Otros gastos: $170 (7% de tus ingresos)"
                    ],
                    adicional: "Noto que podrías reducir un 15% en alimentación optimizando tus compras."
                },
                "default": {
                    titulo: "Basándome en tu pregunta, te recomiendo:",
                    puntos: [
                        "Revisar tus gastos recurrentes y eliminar suscripciones no esenciales",
                        "Establecer un fondo de emergencia equivalente a 3-6 meses de gastos",
                        "Automatizar tus ahorros para garantizar consistencia",
                        "Considerar inversiones de bajo riesgo para hacer crecer tu dinero"
                    ],
                    adicional: "¿Hay algún aspecto específico de tus finanzas en el que te gustaría que me centre?"
                }
            };
            
            // Función para agregar mensaje del usuario al chat
            function agregarMensajeUsuario(mensaje) {
                const elementoMensaje = document.createElement('div');
                elementoMensaje.className = 'pregunta-usuario';
                elementoMensaje.innerHTML = `<p>${mensaje}</p>`;
                chatContainer.appendChild(elementoMensaje);
                
                // Hacer scroll hacia abajo para mostrar el nuevo mensaje
                chatContainer.scrollTop = chatContainer.scrollHeight;
                
                // Simular que la IA está escribiendo
                setTimeout(() => {
                    mensajeCargando.style.display = 'block';
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                    
                    // Simular tiempo de respuesta de la IA
                    setTimeout(() => {
                        mensajeCargando.style.display = 'none';
                        responderIA(mensaje);
                    }, 1500);
                }, 500);
            }
            
            // Función para que la IA responda
            function responderIA(pregunta) {
                const respuesta = respuestasIA[pregunta] || respuestasIA["default"];
                
                const elementoRespuesta = document.createElement('div');
                elementoRespuesta.className = 'respuesta-ia';
                
                let puntosHTML = '';
                respuesta.puntos.forEach(punto => {
                    puntosHTML += `<li>${punto}</li>`;
                });
                
                elementoRespuesta.innerHTML = `
                    <h4>${respuesta.titulo}</h4>
                    <ul>${puntosHTML}</ul>
                    <p>${respuesta.adicional}</p>
                `;
                
                chatContainer.appendChild(elementoRespuesta);
                
                // Hacer scroll hacia abajo para mostrar la respuesta
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }
            
            // Enviar mensaje al hacer clic en el botón
            btnEnviar.addEventListener('click', function() {
                const mensaje = inputMensaje.value.trim();
                if (mensaje) {
                    agregarMensajeUsuario(mensaje);
                    inputMensaje.value = '';
                }
            });
            
            // Enviar mensaje al presionar Enter
            inputMensaje.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    btnEnviar.click();
                }
            });
            
            // Botones de opciones rápidas
            botonesOpciones.forEach(boton => {
                boton.addEventListener('click', function() {
                    const pregunta = this.getAttribute('data-pregunta');
                    agregarMensajeUsuario(pregunta);
                });
            });
            
            // Navegación entre secciones
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    navItems.forEach(nav => nav.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Aquí podrías agregar lógica para cambiar de sección
                    const seccion = this.querySelector('span').textContent;
                    console.log('Navegando a: ' + seccion);
                    
                    // Redirigir a la página correspondiente
                    if (seccion === 'Inicio') {
                        window.location.href = '../index.html'; // Página principal
                    }
                    if (seccion === 'Presupuesto') {
                        window.location.href = 'presupuesto.html'; // Página principal
                    }
                    if (seccion === 'Chat IA') {
                        window.location.href = ''; // Página principal
                    }
                   
                });
            });
            
            // Hacer scroll al final del chat al cargar la página
            chatContainer.scrollTop = chatContainer.scrollHeight;
        });