// JavaScript para funcionalidades interactivas
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle entre opciones
            const toggleOptions = document.querySelectorAll('.toggle-option');
            toggleOptions.forEach(option => {
                option.addEventListener('click', function() {
                    toggleOptions.forEach(opt => opt.classList.remove('active'));
                    this.classList.add('active');
                });
            });
            
            // Navegación entre secciones
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    navItems.forEach(nav => nav.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Aquí podrías agregar lógica para cambiar de sección
                    console.log('Navegando a: ' + this.querySelector('span').textContent);
                });
            });
            
            // Simular actualización de datos (esto sería reemplazado por llamadas a API reales)
            function actualizarDatos() {
                // Simular una actualización del saldo
                const saldoElement = document.querySelector('.saldo-total .monto');
                const saldoActual = parseFloat(saldoElement.textContent.replace('$', '').replace(',', ''));
                const nuevoSaldo = saldoActual + Math.random() * 100;
                saldoElement.textContent = '$' + nuevoSaldo.toFixed(2);
                
                // Simular una nueva transacción
                const transacciones = [
                    { nombre: "Netflix", monto: 15.99, fecha: "Hoy", categoria: "entretenimiento" },
                    { nombre: "Gasolina", monto: 45.75, fecha: "Hoy", categoria: "transporte" },
                    { nombre: "Supermercado", monto: 89.43, fecha: "Ayer", categoria: "comida" }
                ];
                
                const transaccionAleatoria = transacciones[Math.floor(Math.random() * transacciones.length)];
                const listaTransacciones = document.querySelector('.lista-transacciones');
                
                // Crear nueva transacción
                const nuevaTransaccion = document.createElement('li');
                nuevaTransaccion.className = 'transaccion';
                
                // Determinar icono según categoría
                let iconoClase = 'comida';
                let icono = 'fas fa-utensils';
                
                if (transaccionAleatoria.categoria === 'transporte') {
                    iconoClase = 'transporte';
                    icono = 'fas fa-car';
                } else if (transaccionAleatoria.categoria === 'entretenimiento') {
                    iconoClase = 'entretenimiento';
                    icono = 'fas fa-film';
                }
                
                nuevaTransaccion.innerHTML = `
                    <div class="transaccion-info">
                        <div class="icono-transaccion ${iconoClase}">
                            <i class="${icono}"></i>
                        </div>
                        <div class="transaccion-detalles">
                            <h4>${transaccionAleatoria.nombre}</h4>
                            <p>${transaccionAleatoria.fecha}</p>
                        </div>
                    </div>
                    <div class="transaccion-monto">$${transaccionAleatoria.monto.toFixed(2)}</div>
                `;
                
                // Agregar al principio de la lista
                listaTransacciones.insertBefore(nuevaTransaccion, listaTransacciones.firstChild);
                
                // Limitar a 5 transacciones
                if (listaTransacciones.children.length > 5) {
                    listaTransacciones.removeChild(listaTransacciones.lastChild);
                }
            }
            
            // Actualizar datos cada 10 segundos (simulación)
            setInterval(actualizarDatos, 10000);
        });


        // Navegación entre secciones
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    navItems.forEach(nav => nav.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Aquí podrías agregar lógica para cambiar de sección
                    const seccion = this.querySelector('span').textContent;
                    console.log('Navegando a: ' + seccion);
                    
                    // Redirigir a la página correspondiente
                    if (seccion === 'Inicio') {
                        window.location.href = ''; // Página principal
                    }
                    if (seccion === 'Presupuesto') {
                        window.location.href = 'templates/presupuesto.html'; // Página principal
                    }
                    if (seccion === 'Chat IA') {
                        window.location.href = 'templates/chat.html'; // Página principal
                    }
                   
                });
            });